/** Automatically generated file. DO NOT MODIFY */
package com.androidhive.sessions;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}