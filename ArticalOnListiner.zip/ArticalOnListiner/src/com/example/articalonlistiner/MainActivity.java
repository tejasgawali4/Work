package com.example.articalonlistiner;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.example.articalonlistiner.ListAdapter.customButtonListener;

import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.widget.ListView;
import android.widget.Toast;

public class MainActivity extends ActionBarActivity implements
		customButtonListener {

	private ListView listView;
	ListAdapter adapter;
	ArrayList<String> dataItems = new ArrayList<String>();

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		String[] dataArray = getResources().getStringArray(R.array.listdata);
		List<String> dataTemp = Arrays.asList(dataArray);
		dataItems.addAll(dataTemp);
		listView = (ListView) findViewById(R.id.listView);
		adapter = new ListAdapter(MainActivity.this, dataItems);
		adapter.setCustomButtonListner(MainActivity.this);
		listView.setAdapter(adapter);

	}

	@Override
	public void onButtonClickListner(int position, String value) {
		Toast.makeText(MainActivity.this, "Button click " + value,
				Toast.LENGTH_SHORT).show();

	}

}
