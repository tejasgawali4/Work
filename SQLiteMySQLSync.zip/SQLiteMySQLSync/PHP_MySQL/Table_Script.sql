CREATE TABLE IF NOT EXISTS `users` (
  `Id` int(11) NOT NULL,
  `Name` varchar(100) NOT NULL,
  PRIMARY KEY (`Id`)
) 